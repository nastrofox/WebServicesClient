﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ClientRestApi
{
    public partial class Form1 : Form
    {
        private const string UrlBase = "http://localhost/my-app";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private async void GET_Click(object sender, EventArgs e)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.GetAsync(UrlBase);
                    response.EnsureSuccessStatusCode(); // Solleva eccezione se non è successo

                    var content = await response.Content.ReadAsStringAsync();

                    // Verifica se la risposta è in formato JSON
                    if (IsJson(content))
                    {
                        var result = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(content);

                        listView1.Items.Clear();
                        foreach (var item in result)
                        {
                            var listViewItem = new ListViewItem(item.Select(pair => pair.Value.ToString()).ToArray());
                            listView1.Items.Add(listViewItem);
                        }
                    }
                    else
                    {
                        // Gestisci la risposta non JSON
                        MessageBox.Show("La risposta non è in formato JSON.");
                        // Puoi visualizzare il contenuto grezzo nella ListView o fare altre azioni di gestione
                    }
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Errore nella richiesta: {ex.Message}");
            }
        }
        private bool IsJson(string input)
        {
            input = input.Trim();
            return input.StartsWith("{") && input.EndsWith("}")
                   || input.StartsWith("[") && input.EndsWith("]");
        }
        private async void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var requestBody = "{\"nome_tabella\": \"valore_tabella\", \"altro_campo\": \"valore\"}"; // Modificare con i dati da inviare
                    var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                    var response = await client.PostAsync(UrlBase, content);

                    response.EnsureSuccessStatusCode(); // Solleva eccezione se non è successo

                    var responseContent = await response.Content.ReadAsStringAsync();
                    // Gestisci la risposta come desiderato
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Errore nella richiesta: {ex.Message}");
            }
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var requestBody = "{\"nome_tabella\": \"valore_tabella\", \"altro_campo\": \"valore\"}"; // Modificare con i dati da inviare
                    var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                    var response = await client.PutAsync(UrlBase, content);

                    response.EnsureSuccessStatusCode(); // Solleva eccezione se non è successo

                    var responseContent = await response.Content.ReadAsStringAsync();
                    // Gestisci la risposta come desiderato
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Errore nella richiesta: {ex.Message}");
            }
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.DeleteAsync(UrlBase);

                    response.EnsureSuccessStatusCode(); // Solleva eccezione se non è successo

                    var responseContent = await response.Content.ReadAsStringAsync();
                    // Gestisci la risposta come desiderato
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show($"Errore nella richiesta: {ex.Message}");
            }
        }
    }

}